#from django.conf.urls import urls
from django.urls import path, include

from . import views

urlpatterns = [
    path('index', views.index , name='index'),
    path('error', views.error, name='error'),
    path('crud', views.crud , name='crud'),
    path('grupo_del/<str:pk>', views.grupos_del , name='grupos_del'),
    path('grupo_edit/<str:pk>', views.grupos_edit , name='grupos_edit'),
    path('grupo_add', views.grupos_add , name='grupos_add'),
    path('grupo_agregar', views.grupos_agregar , name='grupos_agregar'),
    path('grupo_actualizar', views.grupos_actualizar , name='grupos_actualizar'),

]