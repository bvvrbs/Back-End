from django.apps import AppConfig


class PersonasConfig(AppConfig):
    name = 'personas'
