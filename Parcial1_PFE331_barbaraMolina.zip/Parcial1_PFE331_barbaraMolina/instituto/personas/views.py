from django.shortcuts import render

# Create your views here.
class Grupo:
    nombre = ""
    debut = ""
    integrantes = ""
    instagram = ""
    generacion = ""
    agencia = ""
    pais = ""
    fandom = ""

    def __init__(self, nombre, debut, integrantes, instagram, generacion, agencia, pais, fandom):
        self.nombre = nombre
        self.debut = debut
        self.integrantes = integrantes
        self.instagram = instagram
        self.generacion = generacion
        self.agencia = agencia
        self.pais = pais
        self.fandom = fandom

    def __str__(self):
        return self.nombre+", "+self.debut+", "+self.integrantes+", "+self.instagram+", "+self.generacion+", "+self.agencia+", "+self.pais+", "+self.fandom

g1= Grupo("StrayKids","2018-03-25","8","realstraykids","4ta generación","JYP Entertainment","Corea del Sur","STAY")
g2= Grupo("BTS","2013-06-13","7","bts.bighitofficial","3era generación","Big Hit Music","Corea del Sur","A.R.M.Y")
g3= Grupo("Seventeen","2015-05-26","13","saythename_17","3era generación","PLEDIS Entertainment","Corea del Sur","CARAT")
g4= Grupo("Enhypen","2020-11-20","7","enhypen","4ta generación","BELIFT LAB","Corea del Sur","ENGENE")
g5= Grupo("Tomorrow X Together","2019-03-04","5","txt_bighit","4ta generación","Big Hit Music","Corea del Sur","MOA")
g6= Grupo("ATEEZ","2018-10-24","8","ateez_official_","4ta generación","KQ Produce","Corea del Sur","ATINY")
g7= Grupo("P1Harmony","2020-10-28","6","p1h_official","4ta generación","FNC Entertainment","Corea del Sur","P1ECE")
g8= Grupo("ZEROBASEONE","2023-07-10","9","zb1official","5ta generación","WAKEONE","Corea del Sur","ZE_ROSE")
g9= Grupo("NewJeans","2022-07-22","5","newjeans_official","4ta generación","ADOR","Corea del Sur","Bunnies")
g10= Grupo("TVXQ","2003-12-26","2","tvqx.official","2da generación","SM Entertainment","Corea del Sur","Cassiopeia")

grupos=[g1,g2,g3,g4,g5,g6,g7,g8,g9,g10]

class Usuario:
    rut = ""
    nombre = ""
    celular = ""
    email = ""
    usuario = ""
    contraseña = ""
    #constructor
    def __init__(self, rut, nombre, celular, email, usuario, contraseña):
        self.rut = rut
        self.nombre = nombre
        self.celular = celular
        self.email = email
        self.usuario = usuario
        self.contraseña = contraseña

    def __str__(self):
        return self.rut+", "+self.nombre+", "+self.celular+", "+self.email+", "+self.usuario+", "+self.contraseña


u1 = Usuario("1-1","Susana","4561235","susana@gmail.com","susanita","1234")
u2 = Usuario("2-2","Juan","98765412","juan@gmail.com","juanito","2324")
u3 = Usuario("3-3","Sandra","65465454","sandra@gmail.com","sandrita","3456")
u4 = Usuario("4-4","Pedro","15948712","pedro@gmail.com","pedrito","4567")
u5 = Usuario("5-5","Sofia","62165487","sofia@gmail.com","sofita","5678")
u6 = Usuario("6-6","Melany","23156723","melany@gmail.com","melanita","6789")
u7 = Usuario("7-7","Frida","12378569","frida@gmailcom","fridita","7891")
u8 = Usuario("8-8","Natalia","54213789","natalia@gmail.com","natita","8912")
u9 = Usuario("9-9","Laura","473293784","laura@gmail.com","laurita","9123")
u10 = Usuario("1-0","Martina","29528242","martina@gmail.com","martinita","0123")

usuarios = [u1,u2,u3,u4,u5,u6,u7,u8,u9,u10]

def error(request):
    print("Hola, estoy en error")
    context={}
    return render(request,'personas/error.html', context)


def index(request):
    print("Hola, estoy en el index")
    context={}
    return render(request, 'personas/index.html', context)

def crud(request):
    print("estoy en el crud")
    context={'grupos':grupos}
    return render(request, "personas/grupos_lista.html",context)

def grupos_add(request):
    print("Estoy en grupos_add")
    context={}
    return render(request,"personas/grupos_agregar.html",context)

############################################################

def grupos_agregar(request):
    print("Hola, estoy grupos_agregar")
    context={}
    mensaje = ""

    if request.method == "POST":
        nombre= request.POST['nombre']
        debut = request.POST['debut']
        integrantes = request.POST['integrantes'] 
        instagram = request.POST['instagram']
        generacion = request.POST['generacion']
        agencia = request.POST['agencia']
        pais = request.POST['pais']
        fandom = request.POST['fandom']
        opcion = request.POST['opcion']
       
        if opcion == "Grabar":
           grupo = Grupo(nombre, debut, integrantes, instagram, generacion, agencia, pais, fandom)
           grupos.append(grupo) # agregado a la lista "grabado"
           mensaje="Bien, datos grabados..."

        context = {'grupos':grupos, 'mensaje':mensaje}

    return render(request,"personas/grupos_lista.html",context)   
    



def grupos_actualizar(request):
    print("Hola, estoy en grupos_actualizar")
    context={}
    mensaje = ""

    if request.method == "POST":
        nombre= request.POST['nombre']
        debut = request.POST['debut']
        integrantes = request.POST['integrantes'] 
        instagram = request.POST['instagram']
        generacion = request.POST['generacion']
        agencia = request.POST['agencia']
        pais = request.POST['pais']
        fandom = request.POST['fandom']
        opcion = request.POST['opcion']
       
        if opcion == "Actualizar":
           grupo = Grupo(nombre, debut, integrantes, instagram, generacion, agencia, pais, fandom)
           print("grupo= ",grupo)
           for obj in grupos:
               if obj.nombre == grupo.nombre:
                   print("ingresó al if")
                   obj.nombre = grupo.nombre
                   obj.debut = grupo.debut
                   obj.integrantes = grupo.integrantes
                   obj.instagram = grupo.instagram
                   obj.generacion = grupo.generacion
                   obj.agencia = grupo.agencia
                   obj.pais = grupo.pais
                   obj.fandom = grupo.fandom

                   break
        
           mensaje="Bien, datos actualizados..."

           context = {'grupos':grupos, 'mensaje':mensaje}
            

        if opcion == "Volver a la Lista":
            context = {'grupos':grupos}

            
        return render(request,"personas/grupos_lista.html",context) 

def grupos_del(request,pk):
    print("estoy en grupos_del y la pk=",pk)

    for grupo in grupos:
        if  grupo.nombre == pk:
            grupos.remove(grupo)
            break

    context={'grupos':grupos}
    return render(request, "personas/grupos_lista.html", context)

def grupos_edit(request,pk):
    print("estoy en grupos_edit y la pk=",pk)

    context={}

    for grupo in grupos:
        if  grupo.nombre == pk:
            context={'grupo':grupo}
            break


    return render(request, "personas/grupos_editar.html", context)

def usuarios_valid(request):
    print("Hola, estoy en usuarios_valid")
    context={}
    mensaje = ""

    if request.method == "POST":
        usuario= request.POST['usuario']
        contraseña= request.POST['contraseña']
        opcion= request.POST['opcion']

        if opcion == "Ingresar":
            usuario = Usuario(usuario, contraseña)